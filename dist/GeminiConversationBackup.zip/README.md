# Gemini Conversation Backup

Brave/Chromium extension for saving a static HTML snapshot of the Gemini page open in the active tab.

## Install in Brave

1. Open `brave://extensions`.
2. Turn on **Developer mode**.
3. Choose **Load unpacked** and select this project folder.
4. Open the Gemini conversation to back up, then click the extension icon and choose **สำรองหน้านี้**.

The extension scrolls to the bottom, then back to the top so content that loads during scrolling can appear. It locates Gemini's user-query and model-response elements and saves their nearest shared conversation container, excluding navigation, sidebars, and interactive controls. If it cannot identify both sides of the conversation, it reports an error instead of saving the entire page. The HTML snapshot is encoded as UTF-8; external styles or images may still require an internet connection.

## Package

Run `./compile.sh` to create `dist/GeminiConversationBackup.zip` for sharing or archive.
